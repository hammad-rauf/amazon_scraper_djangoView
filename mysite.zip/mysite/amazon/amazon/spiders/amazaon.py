from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import AmazonItem

from time import sleep


class AmazonSpider(CrawlSpider):

    name = "amazon"

    super_link = "https://www.amazon.ae/"

    link = "https://www.amazon.ae/gp/offer-listing/swap_code/ref=dp_olp_new_mbc?ie=UTF8&condition=new" 

    seller_quantity_link = "&me=swap_code"

    counter = 0


    def __init__(self,*args, **kwargs):                    
        super(AmazonSpider, self).__init__(*args, **kwargs)   

        links = open("/home/hammadrauf/Desktop/mysite/media/link.txt", "r")

        self._url_list = links                                                               

    def start_requests(self):    

        for code in self._url_list: 

            yield Request(url = code, meta={"code":code},callback = self.product)

    def product(self,response):

        link = response.css(".a-spacing-medium .sg-row .rush-component .a-link-normal::attr(href)").extract_first()
        try:
            yield Request(url = self.super_link+link, meta={"code":response.meta["code"]},callback = self.product_page)
        except:
            pass

    def product_page(self, response):

        product = AmazonItem()

        product["id"]  = self.counter
        self.counter += 1

        product["Quantity"] = response.css(".a-dropdown-container  .a-native-dropdown option:last-child::text").extract_first().strip()

        if product["Quantity"] == "English":
            product["Quantity"] = 1
        
        product["Description"] = response.css("#productTitle::text").extract_first().strip()
        
        product["Price"] = response.css("#priceblock_ourprice::text").extract_first().strip().replace("\xa0"," ")  

        product["Image"] = response.css("span.a-list-item .a-button-text img::attr(src)").extract_first()

        check = response.css("#merchant-info::text").extract_first().strip()

        if "Ships from and sold by" in check:
        
            if "Amazon" in check:

                product["Fulfillment"] = "Yes"
                product["Buyer_name"] = "Amazon"
            
            else:
                product["Fulfillment"] = "No"
                product["Buyer_name"] = response.css("#sellerProfileTriggerId::text").extract_first()
        
        else:

            product["Buyer_name"] = response.css("#sellerProfileTriggerId::text").extract_first()

            try:
                product["Fulfillment"] = response.css("#SSOFpopoverLink::text").extract_first()
                product["Fulfillment"] = "Yes"
            except:
                product["Fulfillment"] = "No"


        code_link = response.css("a[href*='offer-listing']::attr(href)").extract_first()

        if code_link:
            yield Request(url = self.super_link+code_link, meta={"product":product,"code":response.meta["code"]},callback = self.seller_page)
        else:
            product["Skus"] = None
            yield product


    def seller_page(self,response):

        product = response.meta["product"]

        sellers = response.css(".a-row.a-spacing-mini.olpOffer")
        
        product["Skus"] = []

        count = 0

        for seller in sellers:

            if count > 0:

                Price = seller.css(".a-size-large.a-color-price.olpOfferPrice.a-text-bold::text").extract_first().strip()
                
                Seller_name = seller.css(".a-spacing-none.olpSellerName .a-size-medium.a-text-bold a::text").extract_first()
                
                if not Seller_name:
                    Seller_name= "Amazon"

                Fulfillment = seller.css(".olpFbaPopoverTrigger::text").extract_first()
                
                if Fulfillment:
                    Fulfillment = "Yes"
                else:
                    Fulfillment = "No"

                sku = {
                "Price":Price,
                "Seller_name": Seller_name,
                "Fulfillment": Fulfillment,
                "Quantity": None    
                }

                seller_id = seller.css(".a-spacing-none.olpSellerName .a-size-medium.a-text-bold a::attr(href)").extract_first()


                seller_id = seller_id.split("&seller=")[1]

                seller_quantity_link = self.seller_quantity_link
                seller_quantity_link = seller_quantity_link.replace("swap_code",seller_id)
                seller_quantity_link = seller_quantity_link.strip(" \n")

                main_link = response.meta["code"]
                main_link = main_link.strip(" \n")

                seller_quantity = main_link+seller_quantity_link

                yield Request(url = seller_quantity,meta={"sku":seller_quantity},callback = self.seller_main_page)     



                product["Skus"].append(sku)

            count += 1        

        yield product


    def seller_main_page(self,response):
        #a[href*='merchant-items']

        a = open("response.txt",'w')
        a.write(response.meta["sku"]+"\n")
        a.write(response.text)

        link = response.css(".a-section.a-spacing-none .rush-component a::attr(href)").extract_first()

        a = open("seller-links.txt","a")
        a.writelines("\n"+response.meta["sku"]+"\n")
        a.writelines(self.super_link+link+"\n")
        yield Request(url = self.super_link+link,meta={"sku":response.meta["sku"]},callback = self.seller_page_quantity)
       

    
    def seller_page_quantity(self,response):

        link = response.css("#quantity option:last-child::text").extract_first()

        a = open("aa.txt","a")
        a.writelines(response.url+"\n")


