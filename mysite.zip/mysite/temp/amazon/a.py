from scrapy import cmdline


def run():
	cmdline.execute("scrapy crawl amazon".split())


