import sqlite3


class AmazonPipeline(object):

    def __init__(self):
        self.create_connection()
        self.create_table()
        pass

    def create_connection(self):
        self.conn = sqlite3.connect("data.db")
        self.curr = self.conn.cursor()

    def create_table(self):
        self.curr.execute(" drop table if exists product")
        self.curr.execute(" drop table if exists product_detail")

        self.curr.execute("create table product(id INTEGER  NOT NULL PRIMARY key,desciption text,Image text,buyer_name text,price text,Fulfillment text,quantity text)")

        self.curr.execute("create table product_detail(id INTEGER  NOT NULL,price text,seller text,Fulfillment text,FOREIGN KEY(id) REFERENCES product(id))")

    def store_db(self,product):

        self.curr.execute(f"insert into product values('{product['id']}','{product['Image']}','{product['Description']}','{product['Buyer_name']}','{product['Price']}','{product['Fulfillment']}','{product['Quantity']}')")

        if not product["Skus"] == None:

            for data in product["Skus"]:

                self.curr.execute(f"insert into product_detail values('{product['id']}','{data['Price']}','{data['Seller_name']}','{data['Fulfillment']}')")

        self.conn.commit()

    def process_item(self, item, spider):
        self.store_db(item)
        return item
