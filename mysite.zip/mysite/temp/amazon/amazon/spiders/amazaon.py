from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import AmazonItem




class AmazonSpider(CrawlSpider):

    name = "amazon"

    super_link = "https://www.amazon.ae/"

    link= "https://www.amazon.ae/gp/offer-listing/swap_code/ref=dp_olp_new_mbc?ie=UTF8&condition=new" 

    counter = 0


    def __init__(self,*args, **kwargs):                    
        super(AmazonSpider, self).__init__(*args, **kwargs)   

        links = open("/home/hammadrauf/Desktop/mysite/media/link.txt", "r")

        self._url_list = links                                                               

    def start_requests(self):    

        for code in self._url_list: 

            yield Request(url = code, meta={"code":code},callback = self.product)

    def product(self,response):

        link = response.css(".a-spacing-medium .sg-row .rush-component .a-link-normal::attr(href)").extract_first()
        try:
            yield Request(url = self.super_link+link, meta={"code":response.meta["code"]},callback = self.product_page)
        except:
            pass

    def product_page(self, response):

        product = AmazonItem()

        product["id"]  = self.counter
        self.counter += 1

        product["Quantity"] = response.css(".a-dropdown-container  .a-native-dropdown option:last-child::text").extract_first().strip()

        if product["Quantity"] == "English":
            product["Quantity"] = 1
        
        product["Description"] = response.css("#productTitle::text").extract_first().strip()
        
        product["Price"] = response.css("#priceblock_ourprice::text").extract_first().strip().replace("\xa0"," ")  

        product["Image"] = response.css("span.a-list-item .a-button-text img::attr(src)").extract_first()

        check = response.css("#merchant-info::text").extract_first().strip()

        if "Ships from and sold by" in check:
        
            if "Amazon" in check:

                product["Fulfillment"] = "Yes"
                product["Buyer_name"] = "Amazon"
            
            else:
                product["Fulfillment"] = "No"
                product["Buyer_name"] = response.css("#sellerProfileTriggerId::text").extract_first()
        
        else:

            product["Buyer_name"] = response.css("#sellerProfileTriggerId::text").extract_first()

            try:
                product["Fulfillment"] = response.css("#SSOFpopoverLink::text").extract_first()
                product["Fulfillment"] = "Yes"
            except:
                product["Fulfillment"] = "No"


        code_link = response.css("a[href*='offer-listing']::attr(href)").extract_first()

        if code_link:
            yield Request(url = self.super_link+code_link, meta={"product":product},callback = self.seller_page)
        else:
            product["Skus"] = None
            yield product


    def seller_page(self,response):

        product = response.meta["product"]

        sellers = response.css(".a-row.a-spacing-mini.olpOffer")
        
        product["Skus"] = []

        count = 0

        for seller in sellers:

            if count > 0:

                Price = seller.css(".a-size-large.a-color-price.olpOfferPrice.a-text-bold::text").extract_first().strip()
                
                Seller_name = seller.css(".a-spacing-none.olpSellerName .a-size-medium.a-text-bold a::text").extract_first()
                
                if not Seller_name:
                    Seller_name= "Amazon"

                Fulfillment = seller.css(".olpFbaPopoverTrigger::text").extract_first()
                
                if Fulfillment:
                    Fulfillment = "Yes"
                else:
                    Fulfillment = "No"

                sku = {
                "Price":Price,
                "Seller_name": Seller_name,
                "Fulfillment": Fulfillment          
                }

                product["Skus"].append(sku)
            
            count += 1
        

        yield product