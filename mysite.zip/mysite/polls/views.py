from django.shortcuts import render
from django.http import HttpResponse
from django.core.files.storage import FileSystemStorage

import sqlite3
import subprocess
import os

database = "/home/hammadrauf/Desktop/mysite/amazon/data.db"


import threading
import time
from scrapyd_api import ScrapydAPI
import subprocess

def scrapy_run():
    os.system("x-terminal-emulator")
    pass


# Create your views here.
def index(request):   

    try:
        os.unlink("/home/hammadrauf/Desktop/mysite/media/link.txt")
    except:
        pass

    conn = sqlite3.connect(database)

    cur = conn.cursor()

    cur.execute("select * from product")

    products = cur.fetchall()

    cur.execute("select * from product_detail")

    products_details = cur.fetchall()


    if request.method == "POST":
        uploaded_file = request.FILES["document"]
        fs = FileSystemStorage()
        fs.save(uploaded_file.name,uploaded_file)

    submitbutton = request.POST.get('submit')    

    if submitbutton:
        t = threading.Thread(target=scrapy_run)
        t.start()
        t.join()


    context = {'products': products,
                'products_details':products_details}

    return render(request, 'polls/index.html', context) 