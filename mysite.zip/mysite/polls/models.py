from django.db import models

# Create your models here.
class Product(models.Model):

    description = models.CharField(max_length=500)
    image = models.URLField(max_length=500)

class ProductDetails(models.Model):

    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    price = models.CharField(max_length=200)
    seller = models.CharField(max_length=200)
    fulfillment = models.CharField(max_length=200)
