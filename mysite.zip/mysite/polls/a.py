from amazon.a import run
run()
